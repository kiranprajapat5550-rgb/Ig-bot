"""Script writing with Gemini (free tier). Output is validated JSON."""
import json
import random
import re
import time

import requests

from . import config

REEL_FORMATS = [
    "Galti jo 90% log karte hain: ek chubhne wali sachchai se shuru karo, phir book ka solution",
    "Ek chhoti kahani (2-3 line ka scene, jaise ek aam insaan ki zindagi) jo book ke ek bade idea par khatam ho",
    "Myth todna: 'Sab kehte hain X, par sach ulta hai' aur book ka tark",
    "Agar tum ye kar rahe ho to ruko: ek warning se shuru karo, phir 3 seedhe amal",
    "Wo 3 sach jo school ne nahi sikhaye, har ek ek chonkane wali line mein",
    "Aaj raat se hi try karne wala ek chhota experiment, book ke hisaab se",
]

REEL_PROMPT = """Tum ek Hindi self-improvement Instagram creator ke liye 30 second ki Reel ka script likh rahe ho. Goal: log pehle 2 second mein na ruke to scroll kar dein, isliye script ko dekhne layak, sunne layak aur share karne layak banao.

Book: {title} (writer: {author})
Is baar ka format: {fmt}
Pehle use ho chuke hooks (inse bilkul alag angle lo): {prev}

Script ka dhaancha (har cheez ek ya do chhoti line):
1. HOOK (10 shabd se kam): pattern-interrupt. Kisi aisi sachchai, galti, darr ya curiosity gap se shuru karo jo seedha dil par lage. 'Namaste dosto' ya 'Aaj hum baat karenge' jaisi shuruaat bilkul nahi.
2. DARD: ek line jo sunne wale ko lage ki ye usi ke baare mein hai.
3. BOOK: ek line mein book ka naam, jaise 'Ye mujhe {title} mein mila.'
4. TEEN INSIGHTS: har ek mein pehle ek tikhi/seedhi baat, phir ek chhota sa aam zindagi ka example ya 'aaj hi ye try karo'. Kuch aisa jo log turant kar sakein.
5. TWIST/PAYOFF: aakhri insight ke baad ek line jo hook se judti ho (loop), taaki log dobara dekhne ka mann karein.
6. CTA: ek line, har baar alag. Comment mein ek shabd likhwao, ya sawal ka jawab comment karne ko kaho, ya 'save kar lo, kal bhool jaoge'.

Style:
- Bolchaal ki Hindi, Devanagari mein, jaise ek dost bol raha ho. 'तुम' use karo. Chhote vaakya, kabhi-kabhi sawal, kabhi-kabhi adhoori baat jo agli line mein poori ho.
- English ke aam shabd (focus, habit, system, goal) Devanagari mein hi likho. Sirf book aur writer ka naam Latin script mein.
- Bhaari-bharkam ya kitabi shabd nahi. Koi filler nahi.
- Book ka summary APNE SHABDON mein. Book se koi line, quote ya paragraph copy mat karo.
- Koi nakli statistic ya guarantee wala daava nahi. '90% log' jaise boli ke andaaz theek hain par pakki sankhya ya study ka naam mat banao.
- Kul 8 se 11 chhoti lines, har line 4 se 12 shabd. Total 70 se 90 shabd.
- keywords: exactly 8 English phrases (2-3 shabd), script ke har hisse ke mood se match karte hue stock video search ke liye (jaise 'tired man desk', 'sunrise running', 'crowd walking city'). Koi brand ya naam nahi.
- caption: 2-3 chhoti Hindi lines + end mein comments ke liye ek sawal. Hashtags caption mein mat do.
- hashtags: exactly 5 relevant hashtags (# ke saath).

Sirf JSON do:
{{"lines": ["..."], "keywords": ["..."], "caption": "...", "hashtags": ["#..."]}}
"""

CAROUSEL_PROMPT = """Tum ek popular Hindi self-improvement Instagram creator ke liye carousel post likh rahe ho.

Book: {title} (writer: {author})
Pehle use ho chuke angles (alag angle lo): {prev}

Rules:
- Summary APNE SHABDON mein, book se koi line ya quote copy mat karo.
- Simple Hindi, Devanagari script mein. Sirf book/writer ka naam Latin script mein.
- cover_title: 8 shabd se kam, curiosity jagane wala. cover_sub: 1 chhoti line.
- Exactly 6 slides. Har slide: heading (max 6 shabd) aur body (max 28 shabd, ek clear actionable idea).
- cta: ek line (save/share/follow ke liye).
- Koi nakli statistic ya guarantee wala daava nahi.
- caption: 2-3 chhoti Hindi lines + comments ke liye ek sawal, hashtags nahi.
- hashtags: exactly 5.

Sirf JSON do:
{{"cover_title": "...", "cover_sub": "...", "slides": [{{"heading": "...", "body": "..."}}], "cta": "...", "caption": "...", "hashtags": ["#..."]}}
"""


def _gemini_json(prompt: str) -> dict:
    if not config.GEMINI_API_KEY:
        raise RuntimeError("GEMINI_API_KEY missing")
    last = ""
    for model in config.GEMINI_MODELS:
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
        for attempt in range(3):
            try:
                r = requests.post(
                    url,
                    headers={"x-goog-api-key": config.GEMINI_API_KEY},
                    json={
                        "contents": [{"parts": [{"text": prompt}]}],
                        "generationConfig": {"temperature": 0.9, "responseMimeType": "application/json"},
                    },
                    timeout=90,
                )
                if r.status_code == 200:
                    text = r.json()["candidates"][0]["content"]["parts"][0]["text"]
                    text = re.sub(r"^```(?:json)?|```$", "", text.strip(), flags=re.M).strip()
                    return json.loads(text)
                last = f"{model} -> {r.status_code}: {r.text[:200]}"
                if r.status_code in (400, 404):
                    break  # try next model name
                time.sleep(6 * (attempt + 1))
            except Exception as e:  # network / JSON problems
                last = f"{model} -> {e}"
                time.sleep(4)
    raise RuntimeError(f"Gemini failed: {last}")


def _clean_tags(tags) -> list[str]:
    out = []
    for t in tags or []:
        t = "#" + re.sub(r"[^\w]", "", str(t).lstrip("#"))
        if len(t) > 1 and t not in out:
            out.append(t)
    return out[:5]


def reel_script(book: dict, prev_hooks: list[str]) -> dict:
    fmt = random.choice(REEL_FORMATS)
    prompt = REEL_PROMPT.format(
        title=book["title"], author=book.get("author", ""), fmt=fmt, prev=prev_hooks or "koi nahi"
    )
    for _ in range(3):
        d = _gemini_json(prompt)
        lines = [str(x).strip() for x in d.get("lines", []) if str(x).strip()]
        words = sum(len(x.split()) for x in lines)
        if 6 <= len(lines) <= 13 and 50 <= words <= 110 and len(d.get("keywords", [])) >= 4:
            return {
                "title": book["title"],
                "author": book.get("author", ""),
                "lines": lines,
                "keywords": [str(k) for k in d["keywords"]][:8],
                "caption": str(d.get("caption", "")).strip(),
                "hashtags": _clean_tags(d.get("hashtags")),
            }
    raise RuntimeError("Gemini returned an unusable reel script 3 times")


def carousel_script(book: dict, prev_hooks: list[str]) -> dict:
    prompt = CAROUSEL_PROMPT.format(
        title=book["title"], author=book.get("author", ""), prev=prev_hooks or "koi nahi"
    )
    for _ in range(3):
        d = _gemini_json(prompt)
        slides = [
            {"heading": str(s.get("heading", "")).strip(), "body": str(s.get("body", "")).strip()}
            for s in d.get("slides", [])
            if s.get("heading") and s.get("body")
        ]
        if len(slides) >= 5 and d.get("cover_title"):
            return {
                "title": book["title"],
                "author": book.get("author", ""),
                "cover_title": str(d["cover_title"]).strip(),
                "cover_sub": str(d.get("cover_sub", "")).strip(),
                "slides": slides[:7],
                "cta": str(d.get("cta", "")).strip(),
                "caption": str(d.get("caption", "")).strip(),
                "hashtags": _clean_tags(d.get("hashtags")),
            }
    raise RuntimeError("Gemini returned an unusable carousel script 3 times")
